import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Verify = () => {
  const navigate = useNavigate();
  const [regno, setRegno] = useState("");
  const [message, setMessage] = useState("");

  const pageStyle = {
    minHeight: "100vh",
    width: "100vw",
    background: "#f0f6fc",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: 0,
  };
  const cardStyle = {
    background: "#fff",
    padding: "2.5rem 2rem",
    borderRadius: "12px",
    boxShadow: "0 0 15px rgba(0,0,0,0.1)",
    textAlign: "center",
    width: "100%",
    maxWidth: 400,
  };
  const headingStyle = {
    color: "#2c3e50",
    marginBottom: "1.5rem",
    fontSize: "2rem",
    fontWeight: 700,
  };
  const inputStyle = {
    width: "100%",
    padding: "12px",
    margin: "10px 0 0 0",
    border: "1px solid #ccc",
    borderRadius: "8px",
    fontSize: "16px",
    display: "block",
    backgroundColor: "#fff",
    color: "#000",
  };
  const buttonStyle = {
    marginTop: "20px",
    padding: "12px 30px",
    fontSize: "16px",
    backgroundColor: "#3498db",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: 600,
    transition: "background 0.3s",
  };
  const backButtonStyle = {
    ...buttonStyle,
    backgroundColor: "#7f8c8d",
    marginTop: "1rem",
  };
  const errorStyle = {
    marginTop: "15px",
    color: "red",
    minHeight: "20px",
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (regno.trim() === "") {
      setMessage("Please enter a Registration Number!");
    } else {
      setMessage("");
      navigate("/voting");
    }
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h2 style={headingStyle}>Voter Verification</h2>
        <form onSubmit={handleSubmit} autoComplete="off">
          <input
            type="text"
            id="regno"
            name="regno"
            placeholder="Enter Registration Number"
            value={regno}
            onChange={(e) => setRegno(e.target.value)}
            
            style={inputStyle}
          />
          <button type="submit" style={buttonStyle}>
            Verify
          </button>
          <div style={errorStyle}>{message}</div>
        </form>
        <button style={backButtonStyle} onClick={() => navigate("/")}>
          Back to Home
        </button>
      </div>
    </div>
  );
};

export default Verify;
